from app import app as application
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
